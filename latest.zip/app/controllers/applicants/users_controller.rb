class Applicants::UsersController < Applicants::UserBaseController
   


    def index
    end
end
