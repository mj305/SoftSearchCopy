class Employers::AdminsController < Employers::AdminBaseController
    
    def index

    end
    
end
