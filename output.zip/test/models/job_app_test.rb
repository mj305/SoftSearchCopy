require 'test_helper'

class JobAppTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
