require 'test_helper'

class UserJobTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
